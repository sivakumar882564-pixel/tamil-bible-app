// ── STATE ──
let curTab='OT', curSlug=null, curCh=null, expBk=null, sbOpen=false;
let vc='#c62828', vbg='#fffdf8', vbd='#f0e0e0', vfs=18, showEN=true;
let srFilter='ALL';

// ── DISPLAY NAMES ──
const TA={}, ENname={};
ORDER.forEach(([s,ta,en])=>{TA[s]=ta; ENname[s]=en;});

// ── SETTINGS ──
function loadS(){
  const s=JSON.parse(localStorage.getItem('tbs2')||'{}');
  vc=s.vc||'#c62828'; vbg=s.vb||'#fffdf8'; vbd=s.vbd||'#f0e0e0';
  vfs=s.fs||18; showEN=s.se!==false;
  applyS();
}
function applyS(){
  document.documentElement.style.setProperty('--vc',vc);
  document.documentElement.style.setProperty('--vbg',vbg);
  document.documentElement.style.setProperty('--vbd',vbd);
  document.documentElement.style.setProperty('--vfs',vfs+'px');
}
function saveS(){localStorage.setItem('tbs2',JSON.stringify({vc,vb:vbg,vbd,fs:vfs,se:showEN}));}
loadS();


// ════════════════════════════════
// STORAGE HELPERS
// ════════════════════════════════
function loadStore(k,d){try{return JSON.parse(localStorage.getItem(k)||'null')||d;}catch(e){return d;}}
function saveStore(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}

var favs=loadStore('tb_favs',{});
var readV=loadStore('tb_read',{});
var pinned=loadStore('tb_pins',{});
var lists=loadStore('tb_lists',[]);
var goal=loadStore('tb_goal',null);
var quizzes=[],quizIdx=0,quizAnswered=false,quizScore=0;
var storyVerses=[],storyIdx=0,storyPaused=false,storyTimer=null;
var goalType='year';
var featTab='fav';
var quizLang='ta';

function vKey(s,c,v){return s+'_'+c+'_'+v;}

function toggleFav(slug,ch,vn,btn){
  var k=vKey(slug,ch,vn);
  if(favs[k]){delete favs[k];}else{favs[k]=true;}
  saveStore('tb_favs',favs);
  if(btn){btn.textContent=favs[k]?'♥':'♡';btn.classList.toggle('on',!!favs[k]);}
  toast(favs[k]?'♥ விருப்பத்தில் சேர்க்கப்பட்டது':'♡ நீக்கப்பட்டது');
}

function toggleRead(slug,ch,vn,btn){
  var k=vKey(slug,ch,vn);
  if(readV[k]){delete readV[k];}else{
    readV[k]=true;
    if(goal){
      var today=new Date().toDateString();
      if(goal.doneToday!==today){goal.doneToday=today;goal.todayDone=0;}
      goal.todayDone=(goal.todayDone||0)+1;
      saveStore('tb_goal',goal);
    }
  }
  saveStore('tb_read',readV);
  if(btn){btn.textContent=readV[k]?'✓ படித்தது':'படிக்க';btn.classList.toggle('on',!!readV[k]);}
}

function togglePin(slug,ch,vn,btn){
  var k=vKey(slug,ch,vn);
  if(pinned[k]){delete pinned[k];}else{pinned[k]=true;}
  saveStore('tb_pins',pinned);
  if(btn){btn.textContent=pinned[k]?'📌 பின்':'📌';btn.classList.toggle('on',!!pinned[k]);}
  toast(pinned[k]?'📌 பின் சேர்க்கப்பட்டது':'📌 நீக்கப்பட்டது');
}

function extraV(slug,ch,vn){
  var k=vKey(slug,ch,vn);
  var fOn=favs[k]?'on':''; var fIc=favs[k]?'♥':'♡';
  var rOn=readV[k]?'on':''; var rTxt=readV[k]?'✓ படித்தது':'படிக்க';
  var pOn=pinned[k]?'on':''; var pTxt=pinned[k]?'📌 பின்':'📌';
  return '<button class="v-fav '+fOn+'" onclick="toggleFav(\''+slug+'\','+ch+','+vn+',this)">'+fIc+'</button>'
    +'<div class="v-badge">'
    +'<button class="vb read '+rOn+'" onclick="toggleRead(\''+slug+'\','+ch+','+vn+',this)">'+rTxt+'</button>'
    +'<button class="vb pin '+pOn+'" onclick="togglePin(\''+slug+'\','+ch+','+vn+',this)">'+pTxt+'</button>'
    +'</div>';
}

function getVerseText(v){
  var tm=TM[v.slug]&&TM[v.slug].chapters&&TM[v.slug].chapters[v.ch]?TM[v.slug].chapters[v.ch][v.vn]||'':'';
  var en=EN[v.slug]&&EN[v.slug][v.ch]?EN[v.slug][v.ch][v.vn]||'':'';
  var ref=TA[v.slug]+' '+v.ch+':'+v.vn+' – '+ENname[v.slug]+' '+v.ch+':'+v.vn;
  return {tm:tm,en:en,ref:ref};
}

function goToVerse(slug,ch,vn){
  openCh(slug,ch);
  setTimeout(function(){
    var nums=document.querySelectorAll('.v-num');
    for(var i=0;i<nums.length;i++){
      if(+nums[i].textContent===+vn){
        var card=nums[i].closest('.verse-card');
        if(card){card.scrollIntoView({behavior:'smooth',block:'center'});card.style.boxShadow='0 0 0 3px #1a237e';setTimeout(function(c){c.style.boxShadow='';},2000,card);}
        break;
      }
    }
  },400);
}

function copyListVerses(lid,onlySelected){
  var l=lists.find(function(x){return x.id===lid;});
  if(!l||!l.items.length){toast('வசனங்கள் இல்லை');return;}
  var items=l.items;
  if(onlySelected){
    var cbs=document.querySelectorAll('.list-cb:checked');
    if(!cbs.length){toast('வசனங்களை தேர்ந்தெடுக்கவும்');return;}
    var keys=Array.from(cbs).map(function(cb){return cb.value;});
    items=items.filter(function(v){return keys.indexOf(vKey(v.slug,v.ch,v.vn))!==-1;});
  }
  var txt=items.map(function(v){var d=getVerseText(v);return d.tm+(d.en?'\n'+d.en:'')+'\n— '+d.ref;}).join('\n\n');
  copyText(txt);
}

function shareListVerses(lid,onlySelected){
  var l=lists.find(function(x){return x.id===lid;});
  if(!l||!l.items.length){toast('வசனங்கள் இல்லை');return;}
  var items=l.items;
  if(onlySelected){
    var cbs=document.querySelectorAll('.list-cb:checked');
    if(!cbs.length){toast('வசனங்களை தேர்ந்தெடுக்கவும்');return;}
    var keys=Array.from(cbs).map(function(cb){return cb.value;});
    items=items.filter(function(v){return keys.indexOf(vKey(v.slug,v.ch,v.vn))!==-1;});
  }
  var txt=items.map(function(v){var d=getVerseText(v);return d.tm+(d.en?'\n'+d.en:'')+'\n— '+d.ref;}).join('\n\n');
  if(navigator.share){navigator.share({title:l.name,text:txt}).catch(function(){copyText(txt);});}
  else{copyText(txt);}
}

function showAddToList(slug,ch,vn){
  if(!lists.length){toast('★ > பட்டியல் → புதிய பட்டியல் உருவாக்கவும்');return;}
  var opts=lists.map(function(l){return '<option value="'+l.id+'">'+l.name+'</option>';}).join('');
  var d=document.createElement('div');
  d.id='addListDlg';
  d.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:3000;display:flex;align-items:center;justify-content:center;padding:20px';
  d.innerHTML='<div style="background:#fff;border-radius:12px;padding:20px;width:min(320px,100%);font-family:Latha,serif;position:relative">'
    +'<button onclick="document.getElementById(\'addListDlg\').remove()" style="position:absolute;top:10px;right:12px;background:none;border:none;font-size:1.2rem;cursor:pointer;color:#888;padding:2px 6px">✕</button>'
    +'<div style="font-weight:bold;color:#1a237e;margin-bottom:12px;padding-right:30px">பட்டியலில் சேர்</div>'
    +'<select id="dlgSel" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:8px;margin-bottom:12px;font-family:Latha,serif">'+opts+'</select>'
    +'<div style="display:flex;gap:8px;justify-content:flex-end">'
    +'<button onclick="document.getElementById(\'addListDlg\').remove()" style="padding:7px 16px;border:1px solid #ddd;border-radius:20px;cursor:pointer;font-family:Latha,serif">ரத்து</button>'
    +'<button onclick="doAddToList(\''+slug+'\','+ch+','+vn+');document.getElementById(\'addListDlg\').remove()" style="padding:7px 16px;background:#1a237e;color:#fff;border:none;border-radius:20px;cursor:pointer;font-family:Latha,serif">சேர்</button>'
    +'</div></div>';
  document.body.appendChild(d);
}
function doAddToList(slug,ch,vn){
  var sel=document.getElementById('dlgSel');if(!sel)return;
  var l=lists.find(function(x){return x.id===sel.value;});if(!l)return;
  var k=vKey(slug,ch,vn);
  if(l.items.find(function(i){return vKey(i.slug,i.ch,i.vn)===k;})){toast('ஏற்கனவே பட்டியலில் உள்ளது');return;}
  l.items.push({slug:slug,ch:+ch,vn:+vn});
  saveStore('tb_lists',lists);
  toast('✓ பட்டியலில் சேர்க்கப்பட்டது!');
}

function showFeat(tab){
  curSlug=null;curCh=null;
  featTab=tab||featTab||'fav';
  var tabs=[
    {id:'fav',label:'♥ விருப்பம்'},
    {id:'read',label:'✓ படித்தது'},
    {id:'pin',label:'📌 பின்'},
    {id:'lists',label:'📋 பட்டியல்'},
    {id:'story',label:'📖 கதை'},
    {id:'goal',label:'🎯 குறிக்கோள்'},
    {id:'quiz',label:'❓ வினா'}
  ];
  var tabHtml=tabs.map(function(t){return '<button class="fn-tab'+(featTab===t.id?' on':'')+'" onclick="showFeat(\''+t.id+'\')">'+(t.label)+'</button>';}).join('');
  var body='';
  if(featTab==='fav')body=renderFavPage();
  else if(featTab==='read')body=renderReadPage();
  else if(featTab==='pin')body=renderPinPage();
  else if(featTab==='lists')body=renderListsPage();
  else if(featTab==='story')body=renderStoryPage();
  else if(featTab==='goal')body=renderGoalPage();
  else if(featTab==='quiz')body=renderQuizPage();
  document.getElementById('main').innerHTML='<div class="bc"><a onclick="showHome()">முகப்பு</a><span class="sep">›</span><span>சிறப்பு அம்சங்கள்</span></div>'
    +'<div class="feat-nav">'+tabHtml+'</div>'+body;
  if(featTab==='story')initStory();
  else if(featTab==='quiz')initQuiz();
}

function verseItem(v,delFn){
  var d=getVerseText(v);
  var ref=TA[v.slug]+' '+v.ch+':'+v.vn+' · '+ENname[v.slug]+' '+v.ch+':'+v.vn;
  return '<div class="feat-item" onclick="goToVerse(\''+v.slug+'\','+v.ch+','+v.vn+')">'
    +'<div class="fi-ref">'+ref+'</div>'
    +'<div class="fi-ta">'+d.tm+'</div>'
    +(d.en?'<div class="fi-en">'+d.en+'</div>':'')
    +(delFn?'<button class="fi-del" onclick="event.stopPropagation();'+delFn+'">✕</button>':'')
    +'</div>';
}

function listVerseItem(v,lid){
  var d=getVerseText(v);
  var k=vKey(v.slug,v.ch,v.vn);
  var ref=TA[v.slug]+' '+v.ch+':'+v.vn+' · '+ENname[v.slug]+' '+v.ch+':'+v.vn;
  return '<div class="feat-item" style="padding-left:38px;position:relative">'
    +'<input type="checkbox" class="list-cb" value="'+k+'" style="position:absolute;left:12px;top:14px;width:16px;height:16px;cursor:pointer">'
    +'<div class="fi-ref" style="cursor:pointer" onclick="goToVerse(\''+v.slug+'\','+v.ch+','+v.vn+')">'+ref+' ↗</div>'
    +'<div class="fi-ta" style="cursor:pointer" onclick="goToVerse(\''+v.slug+'\','+v.ch+','+v.vn+')">'+d.tm+'</div>'
    +(d.en?'<div class="fi-en">'+d.en+'</div>':'')
    +'<button class="fi-del" onclick="event.stopPropagation();removeFromListUI(\''+lid+'\',\''+v.slug+'\','+v.ch+','+v.vn+')">✕</button>'
    +'</div>';
}

function renderFavPage(){
  var keys=Object.keys(favs);
  if(!keys.length)return '<div class="feat-empty">♡ விருப்பமான வசனங்கள் இன்னும் சேர்க்கப்படவில்லை</div>';
  var items=keys.map(function(k){var p=k.split('_');return {slug:p[0],ch:+p[1],vn:+p[2]};});
  return '<div class="feat-page"><h2>♥ விருப்பமான வசனங்கள் ('+items.length+')</h2>'+items.map(function(v){return verseItem(v,'removeFav(\''+vKey(v.slug,v.ch,v.vn)+'\')');}).join('')+'</div>';
}
function removeFav(k){delete favs[k];saveStore('tb_favs',favs);showFeat('fav');}

function renderReadPage(){
  var keys=Object.keys(readV);
  if(!keys.length)return '<div class="feat-empty">✓ படித்த வசனங்கள் இல்லை</div>';
  var items=keys.map(function(k){var p=k.split('_');return {slug:p[0],ch:+p[1],vn:+p[2]};});
  return '<div class="feat-page"><h2>✓ படித்த வசனங்கள் ('+items.length+')</h2>'+items.map(function(v){return verseItem(v,'');}).join('')+'</div>';
}

function renderPinPage(){
  var keys=Object.keys(pinned);
  if(!keys.length)return '<div class="feat-empty">📌 பின் சேர்க்கப்பட்ட வசனங்கள் இல்லை</div>';
  var items=keys.map(function(k){var p=k.split('_');return {slug:p[0],ch:+p[1],vn:+p[2]};});
  return '<div class="feat-page"><h2>📌 பின் சேர்க்கப்பட்ட வசனங்கள் ('+items.length+')</h2>'+items.map(function(v){return verseItem(v,'removePin(\''+vKey(v.slug,v.ch,v.vn)+'\')');}).join('')+'</div>';
}
function removePin(k){delete pinned[k];saveStore('tb_pins',pinned);showFeat('pin');}

var curListId=null;
function renderListsPage(){
  var selList=lists.find(function(l){return l.id===curListId;})||lists[0]||null;
  curListId=selList?selList.id:null;
  var listOpts=lists.map(function(l){return '<option value="'+l.id+'"'+(l.id===curListId?' selected':'')+'>'+l.name+'</option>';}).join('');
  var itemsHtml='<div class="feat-empty">வசனங்கள் இல்லை</div>';
  if(selList&&selList.items.length){
    itemsHtml='<label style="font-size:.72rem;color:#555;display:flex;align-items:center;gap:6px;margin-bottom:8px;cursor:pointer"><input type="checkbox" id="selAll" onchange="document.querySelectorAll(\'.list-cb\').forEach(function(c){c.checked=document.getElementById(\'selAll\').checked;});"> அனைத்தையும் தேர்ந்தெடு</label>'
      +selList.items.map(function(v){return listVerseItem(v,selList.id);}).join('');
  }
  var actBtns='';
  if(selList&&selList.items.length){
    actBtns='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">'
      +'<button class="list-btn" onclick="copyListVerses(\''+selList.id+'\',true)">📋 தேர்ந்த நகல்</button>'
      +'<button class="list-btn" onclick="copyListVerses(\''+selList.id+'\',false)">📋 அனைத்தும் நகல்</button>'
      +'<button class="list-btn" onclick="shareListVerses(\''+selList.id+'\',true)">🔗 தேர்ந்த பகிர்</button>'
      +'<button class="list-btn" onclick="shareListVerses(\''+selList.id+'\',false)">🔗 அனைத்தும் பகிர்</button>'
      +'</div>';
  }
  return '<div class="feat-page"><h2>📋 வசன பட்டியல்கள்</h2>'
    +'<div class="list-new-row"><input type="text" id="newListName" placeholder="புதிய பட்டியல் பெயர்..." onkeydown="if(event.key===\'Enter\')createList()"/><button onclick="createList()">+ உருவாக்கு</button></div>'
    +(lists.length?'<div class="list-header"><select class="list-sel" onchange="curListId=this.value;showFeat(\'lists\')">'+listOpts+'</select><button class="list-btn" style="background:#c62828" onclick="delCurList()">நீக்கு</button></div>':'')
    +actBtns
    +(selList?'<div id="listItems">'+itemsHtml+'</div>':'<div class="feat-empty">மேலே புதிய பட்டியல் உருவாக்கவும்</div>')
    +'</div>';
}
function createList(){var n=document.getElementById('newListName');if(!n||!n.value.trim()){toast('பட்டியல் பெயர் உள்ளிடவும்');return;}lists.push({id:Date.now()+'',name:n.value.trim(),items:[]});curListId=lists[lists.length-1].id;saveStore('tb_lists',lists);showFeat('lists');}
function delCurList(){if(!curListId)return;lists=lists.filter(function(l){return l.id!==curListId;});curListId=lists[0]?lists[0].id:null;saveStore('tb_lists',lists);showFeat('lists');}
function removeFromListUI(lid,slug,ch,vn){var l=lists.find(function(x){return x.id===lid;});if(!l)return;var k=vKey(slug,ch,vn);l.items=l.items.filter(function(i){return vKey(i.slug,i.ch,i.vn)!==k;});saveStore('tb_lists',lists);showFeat('lists');}

function renderStoryPage(){
  var bookOpts=ORDER.map(function(b){return '<option value="'+b[0]+'">'+TA[b[0]]+' ('+b[2]+')</option>';}).join('');
  return '<div style="max-width:600px;margin:0 auto"><div class="feat-page"><h2>📖 கதை வாசிப்பு முறை</h2>'
    +'<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;align-items:center"><label style="font-size:.75rem;color:#555">புத்தகம்:</label><select id="storyBook" style="border:1px solid #ddd;padding:4px 8px;border-radius:8px;font-size:.75rem;font-family:Latha,serif;flex:1">'+bookOpts+'</select></div>'
    +'<div style="display:flex;gap:8px;align-items:center;margin-bottom:10px"><span style="font-size:.75rem;color:#555">வேகம்:</span><input type="range" id="storySpeed" min="2" max="15" value="6" style="flex:1" oninput="document.getElementById(\'storySpeedLbl\').textContent=this.value+\' வி\'"><span id="storySpeedLbl" style="font-size:.7rem;color:#888;width:36px">6 வி</span></div>'
    +'<button onclick="startStory()" style="background:#1a237e;color:#fff;border:none;padding:9px 20px;border-radius:20px;font-size:.8rem;cursor:pointer;font-family:Latha,serif;width:100%">▶ தொடங்கு</button></div><div id="storyDisplay"></div></div>';
}
function initStory(){}
function startStory(){
  var el=document.getElementById('storyBook');var slug=el?el.value:'genesis';
  storyVerses=[];var bk=TM[slug];if(!bk||!bk.chapters)return;
  var chs=Object.keys(bk.chapters).map(Number).sort(function(a,b){return a-b;});
  chs.forEach(function(ch){var vss=bk.chapters[ch];Object.keys(vss).map(Number).sort(function(a,b){return a-b;}).forEach(function(vn){storyVerses.push({slug:slug,ch:ch,vn:vn,txt:vss[vn],en:(EN[slug]&&EN[slug][ch]?EN[slug][ch][vn]||'':''),ref:TA[slug]+' '+ch+':'+vn});});});
  storyIdx=0;storyPaused=false;showStoryVerse();
}
function showStoryVerse(){
  clearTimeout(storyTimer);
  var el=document.getElementById('storyDisplay');if(!el)return;
  if(storyIdx>=storyVerses.length){el.innerHTML='<div style="text-align:center;padding:30px;color:#1a237e">✓ புத்தகம் முடிந்தது!</div>';return;}
  var v=storyVerses[storyIdx];
  var spd=+(document.getElementById('storySpeed')?document.getElementById('storySpeed').value:6)*1000;
  el.innerHTML='<div class="story-card"><div class="story-ta">'+v.txt+'</div>'+(v.en?'<div class="story-en">'+v.en+'</div>':'')+'<div class="story-ref">'+v.ref+'</div></div>'
    +'<div class="story-controls">'
    +'<button class="story-btn" onclick="storyIdx=Math.max(0,storyIdx-1);showStoryVerse()" '+(storyIdx===0?'disabled':'')+'>&#9664; முந்தைய</button>'
    +'<button class="story-btn" id="storyPauseBtn" onclick="toggleStoryPause()">⏸ நிறுத்து</button>'
    +'<button class="story-btn" onclick="storyIdx++;showStoryVerse()">அடுத்தது &#9654;</button>'
    +'</div>'
    +'<div class="story-prog">'+(storyIdx+1)+' / '+storyVerses.length+' — '+v.ref+'</div>';
  if(!storyPaused)storyTimer=setTimeout(function(){storyIdx++;showStoryVerse();},spd);
}
function toggleStoryPause(){storyPaused=!storyPaused;if(!storyPaused){showStoryVerse();}else{clearTimeout(storyTimer);var b=document.getElementById('storyPauseBtn');if(b)b.textContent='▶ தொடர்';}}

var TOTAL_VERSES=31102;
function renderGoalPage(){
  if(goal)return renderGoalActive();
  var yOn=goalType==='year'?' on':'';var mOn=goalType==='month'?' on':'';var oOn=goalType==='own'?' on':'';
  return '<div class="feat-page"><h2>🎯 வாசிப்பு குறிக்கோள்</h2>'
    +'<p style="font-size:.78rem;color:#666;margin-bottom:12px">வேதாகமம் முழுவதும் படிக்க திட்டமிடுங்கள் (31,102 வசனங்கள்)</p>'
    +'<div class="goal-opts">'
    +'<div class="goal-opt'+yOn+'" onclick="setGoalType(\'year\')"><h3>📅 1 வருடம்</h3><small>~85 வ/நாள்</small></div>'
    +'<div class="goal-opt'+mOn+'" onclick="setGoalType(\'month\')"><h3>📆 1 மாதம்</h3><small>~1037 வ/நாள்</small></div>'
    +'<div class="goal-opt'+oOn+'" onclick="setGoalType(\'own\')"><h3>⏱ சொந்த</h3><small>நீங்களே அமைக்கவும்</small></div>'
    +'</div>'
    +'<div id="ownPaceDiv" style="display:'+(goalType==='own'?'block':'none')+'">'
    +'<div class="own-pace-opts"><div class="op-row"><span>நாட்கள்:</span><input type="number" id="goalDays" min="1" max="3650" value="90" oninput="recalcGoal()"/></div>'
    +'<div id="goalCalc" style="font-size:.72rem;color:#1a237e;margin-top:4px"></div></div></div>'
    +'<button class="goal-start-btn" onclick="startGoal()">🎯 தொடங்கு</button></div>';
}
function setGoalType(t){goalType=t;document.querySelectorAll('.goal-opt').forEach(function(el,i){el.classList.toggle('on',['year','month','own'][i]===t);});var od=document.getElementById('ownPaceDiv');if(od)od.style.display=(t==='own'?'block':'none');recalcGoal();}
function recalcGoal(){var gd=document.getElementById('goalDays');if(!gd)return;var el=document.getElementById('goalCalc');if(el)el.textContent='நாளுக்கு ~'+Math.ceil(TOTAL_VERSES/(+gd.value||90))+' வசனங்கள் படிக்க வேண்டும்';}
function startGoal(){var days,vpd;if(goalType==='year'){days=365;vpd=85;}else if(goalType==='month'){days=30;vpd=1037;}else{var gd=document.getElementById('goalDays');days=gd?+gd.value||90:90;vpd=Math.ceil(TOTAL_VERSES/days);}goal={type:goalType,days:days,vpd:vpd,start:Date.now(),doneToday:null,todayDone:0};saveStore('tb_goal',goal);showFeat('goal');}
function renderGoalActive(){
  var elapsed=Math.max(1,Math.floor((Date.now()-goal.start)/86400000)+1);
  var rc=Object.keys(readV).length;
  var pct=Math.min(100,Math.round(rc/TOTAL_VERSES*100));
  var today=new Date().toDateString();
  var td=goal.doneToday===today?goal.todayDone:0;
  var tpct=Math.min(100,Math.round(td/goal.vpd*100));
  var tLbl={year:'1 வருடம்',month:'1 மாதம்',own:'சொந்த திட்டம்'}[goal.type];
  return '<div class="feat-page"><h2>🎯 வாசிப்பு குறிக்கோள்</h2>'
    +'<div class="goal-card"><div style="font-size:.82rem;font-weight:bold;color:#1a237e;margin-bottom:8px">'+tLbl+' — நாள் '+elapsed+'/'+goal.days+'</div>'
    +'<div class="goal-bar-wrap"><div class="goal-bar" style="width:'+pct+'%"></div></div>'
    +'<div class="goal-stat">'+rc+' / '+TOTAL_VERSES+' வசனங்கள் படிக்கப்பட்டது ('+pct+'%)</div></div>'
    +'<div style="background:#eef2ff;border:1px solid #c5cae9;border-radius:8px;padding:12px;margin-bottom:10px">'
    +'<div style="font-size:.8rem;font-weight:bold;color:#1a237e;margin-bottom:4px">இன்றைய இலக்கு: '+goal.vpd+' வசனங்கள்</div>'
    +'<div class="goal-bar-wrap"><div class="goal-bar" style="width:'+tpct+'%;background:#e91e63"></div></div>'
    +'<div class="goal-stat">'+td+' / '+goal.vpd+' இன்று படிக்கப்பட்டது</div></div>'
    +'<button onclick="if(confirm(\'\u0b95\u0bc1\u0bb1\u0bbf\u0b95\u0bcd\u0b95\u0bcb\u0bb3\u0bc8 \u0bae\u0bc0\u0b9f\u0bcd\u0b9f\u0bae\u0bc8\u0b95\u0bcd\u0b95\u0bb5\u0bc1\u0bae\u0bbe?\')){goal=null;saveStore(\'tb_goal\',null);goalType=\'year\';showFeat(\'goal\')}" style="background:#c62828;color:#fff;border:none;padding:8px 18px;border-radius:20px;font-size:.75rem;cursor:pointer">மீட்டமை</button>'
    +'</div>';
}

function buildQuiz(){
  var pool=[];
  ORDER.forEach(function(b){
    var slug=b[0];var bk=TM[slug];if(!bk||!bk.chapters)return;
    Object.keys(bk.chapters).forEach(function(ch){var vss=bk.chapters[ch];Object.keys(vss).forEach(function(vn){var tm=vss[vn];var en=EN[slug]&&EN[slug][ch]?EN[slug][ch][vn]||'':'';if(tm&&tm.length>15&&tm.length<200)pool.push({slug:slug,ch:+ch,vn:+vn,tm:tm,en:en});});});
  });
  for(var i=pool.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=pool[i];pool[i]=pool[j];pool[j]=t;}
  quizzes=pool.slice(0,20).map(function(v,qi){return buildQuestion(v,qi);});
  quizIdx=0;quizAnswered=false;quizScore=0;
}
function buildQuestion(v,qi){
  var isTa=(quizLang==='ta');
  var qText=isTa?v.tm:v.en;if(!qText)qText=isTa?v.en:v.tm;
  var cb=isTa?TA[v.slug]:ENname[v.slug];
  var others=ORDER.filter(function(b){return b[0]!==v.slug;}).map(function(b){return isTa?TA[b[0]]:b[2];});
  for(var i=others.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=others[i];others[i]=others[j];others[j]=t;}
  if(qi%2===0){
    var opts=[cb,others[0],others[1],others[2]];
    for(var i=opts.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=opts[i];opts[i]=opts[j];opts[j]=t;}
    var qL=isTa?'இந்த வசனம் எந்த புத்தகத்தில் உள்ளது?':'Which book contains this verse?';
    var sn=qText.substring(0,100)+(qText.length>100?'...':'');
    return {q:qL+'\n"'+sn+'"',opts:opts,ans:cb,ref:(isTa?TA[v.slug]:ENname[v.slug])+' '+v.ch+':'+v.vn};
  } else {
    var words=qText.split(' ');var half=Math.ceil(words.length/2);
    var q1=words.slice(0,half).join(' ')+'...';
    var ans=qText.substring(0,80)+(qText.length>80?'...':'');
    var wrongs=[];
    for(var wi=0;wi<10&&wrongs.length<3;wi++){
      var ws=ORDER[Math.floor(Math.random()*ORDER.length)][0];
      var wb=TM[ws];if(!wb||!wb.chapters)continue;
      var wcs=Object.keys(wb.chapters);var wc=wcs[Math.floor(Math.random()*wcs.length)];
      var wvs=wb.chapters[wc];var wns=Object.keys(wvs);var wn=wns[Math.floor(Math.random()*wns.length)];
      var wt=isTa?wvs[wn]:(EN[ws]&&EN[ws][wc]?EN[ws][wc][wn]||'':'');
      if(wt&&wt!==qText&&wt.length>10)wrongs.push(wt.substring(0,80)+(wt.length>80?'...':''));
    }
    while(wrongs.length<3)wrongs.push(isTa?'வேறு வசனம்':'Another verse');
    var wopts=[ans,wrongs[0],wrongs[1],wrongs[2]];
    for(var i=wopts.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var tw=wopts[i];wopts[i]=wopts[j];wopts[j]=tw;}
    var qL2=isTa?'இந்த வசனத்தை நிறைவு செய்யுங்கள்:':'Complete this verse:';
    return {q:qL2+'\n"'+q1+'"',opts:wopts,ans:ans,ref:(isTa?TA[v.slug]:ENname[v.slug])+' '+v.ch+':'+v.vn};
  }
}
function setQuizLang(lang){quizLang=lang;buildQuiz();showFeat('quiz');}
function renderQuizPage(){
  var taOn=quizLang==='ta'?'background:#1a237e;color:#fff;':'';
  var enOn=quizLang==='en'?'background:#1a237e;color:#fff;':'';
  return '<div><div style="display:flex;gap:8px;align-items:center;margin-bottom:10px;flex-wrap:wrap">'
    +'<span style="font-size:.78rem;color:#555">மொழி / Language:</span>'
    +'<button onclick="setQuizLang(\'ta\')" style="padding:5px 14px;border-radius:20px;border:1px solid #1a237e;cursor:pointer;font-family:Latha,serif;font-size:.75rem;'+taOn+'">தமிழ்</button>'
    +'<button onclick="setQuizLang(\'en\')" style="padding:5px 14px;border-radius:20px;border:1px solid #1a237e;cursor:pointer;font-size:.75rem;'+enOn+'">English</button>'
    +'</div><div id="quizContainer"></div></div>';
}
function initQuiz(){buildQuiz();renderCurrentQuiz();}
function renderCurrentQuiz(){
  var el=document.getElementById('quizContainer');if(!el)return;
  var isTa=quizLang==='ta';
  if(quizIdx>=quizzes.length){
    var icon=quizScore>=15?'🏆':quizScore>=10?'🎉':'👍';
    el.innerHTML='<div class="feat-page" style="text-align:center">'
      +'<h2>❓ '+(isTa?'வினாவிடை முடிந்தது!':'Quiz Complete!')+'</h2>'
      +'<div style="font-size:2.2rem;margin:16px 0">'+icon+'</div>'
      +'<div style="font-size:1.1rem;font-weight:bold;color:#1a237e">'+quizScore+' / '+quizzes.length+(isTa?' சரி':' correct')+'</div>'
      +'<div style="font-size:.8rem;color:#888;margin:6px 0">'+(quizScore>=15?(isTa?'அருமை! தேர்ச்சி பெற்றீர்கள்!':'Excellent!'):quizScore>=10?(isTa?'நல்ல முயற்சி!':'Good effort!'):(isTa?'தொடர்ந்து படிக்கவும்!':'Keep reading!'))+'</div>'
      +'<button onclick="buildQuiz();renderCurrentQuiz()" style="background:#1a237e;color:#fff;border:none;padding:10px 24px;border-radius:20px;font-size:.8rem;cursor:pointer;margin-top:14px">'+(isTa?'மீண்டும் முயற்சிக்கவும்':'Try Again')+'</button>'
      +'</div>';
    return;
  }
  var q=quizzes[quizIdx];
  var optsHtml=q.opts.map(function(o,i){return '<button class="quiz-opt" id="qopt'+i+'" onclick="answerQuiz('+i+')">'+o+'</button>';}).join('');
  var prevLbl=isTa?'&#9664; முந்தைய':'&#9664; Prev';
  var nextLbl=isTa?'அடுத்தது &#9654;':'Next &#9654;';
  el.innerHTML='<div class="quiz-card">'
    +'<div class="quiz-num">'+(isTa?'வினா ':'Q ')+(quizIdx+1)+' / '+quizzes.length+' · '+(isTa?'மதிப்பெண்: ':'Score: ')+quizScore+'</div>'
    +'<div class="quiz-q">'+q.q.replace(/\n/g,'<br>')+'</div>'
    +'<div class="quiz-opts">'+optsHtml+'</div>'
    +'<div id="quizFeedback"></div>'
    +'<div class="quiz-nav">'+(quizIdx>0?'<button onclick="quizIdx--;quizAnswered=false;renderCurrentQuiz()">'+prevLbl+'</button>':'')
    +'<button onclick="quizIdx++;quizAnswered=false;renderCurrentQuiz()">'+nextLbl+'</button></div></div>';
}
function answerQuiz(i){
  if(quizAnswered)return;quizAnswered=true;
  var q=quizzes[quizIdx];var correct=q.opts[i]===q.ans;if(correct)quizScore++;
  q.opts.forEach(function(o,idx){var btn=document.getElementById('qopt'+idx);if(!btn)return;btn.disabled=true;if(o===q.ans)btn.classList.add('correct');else if(idx===i)btn.classList.add('wrong');});
  var fb=document.getElementById('quizFeedback');var isTa=quizLang==='ta';
  if(fb)fb.innerHTML='<div class="quiz-score">'+(correct?(isTa?'✓ சரியான பதில்!':'✓ Correct!'):(isTa?'✗ தவறு — சரி: ':'✗ Wrong — Correct: ')+q.ans)+'</div>'
    +'<div style="font-size:.68rem;color:#999;text-align:center;margin-top:2px">('+q.ref+')</div>';
}

// ── SIDEBAR ──
function toggleSB(){
  sbOpen=!sbOpen;
  document.getElementById('sb').classList.toggle('open',sbOpen);
  document.getElementById('sbo').classList.toggle('on',sbOpen);
}
function closeSB(){sbOpen=false;document.getElementById('sb').classList.remove('open');document.getElementById('sbo').classList.remove('on');}
function switchTab(t){
  curTab=t;
  document.getElementById('tab-ot').classList.toggle('on',t==='OT');
  document.getElementById('tab-nt').classList.toggle('on',t==='NT');
  buildSB(t,'');
}
function buildSB(tab,filter){
  const list=document.getElementById('sb-list');
  const bks=ORDER.filter(([,,,t])=>t===tab);
  let n=tab==='OT'?1:40,html='';
  bks.forEach(([slug,,en])=>{
    const ta=TA[slug];
    if(filter&&!ta.includes(filter)&&!en.toLowerCase().includes(filter.toLowerCase())){n++;return;}
    const chs=Object.keys(TM[slug]?.chapters||{}).map(Number).sort((a,b)=>a-b);
    const isCur=slug===curSlug,isExp=slug===expBk;
    const chHtml=chs.map(c=>`<div class="sb-ch${curSlug===slug&&curCh===c?' on':''}" onclick="openCh('${slug}',${c});event.stopPropagation()">${c}</div>`).join('');
    html+=`<div class="sb-bk${isExp?' exp':''}" id="sbk-${slug}">
      <div class="sb-bk-row${isCur?' cur':''}" onclick="toggleBk('${slug}')">
        <span class="sb-num">${n}</span>
        <span class="sb-ta">${ta}</span>
        <span class="sb-en">${en}</span>
        <span class="sb-arr">▶</span>
      </div>
      <div class="sb-chs">${chHtml}</div>
    </div>`;
    n++;
  });
  list.innerHTML=html||'<div style="padding:20px;text-align:center;color:#aaa">கிடைக்கவில்லை</div>';
}
function toggleBk(slug){
  expBk=expBk===slug?null:slug;
  if(expBk) showBook(slug);
  rebuildSB();
}
function rebuildSB(){buildSB(curTab,document.getElementById('sb-q').value);}
function filterSB(v){buildSB(curTab,v);}

// ── ROUTER ──
function showHome(){curSlug=null;curCh=null;expBk=null;renderHome();closeSB();}
function showBook(slug){
  curSlug=slug;curCh=null;
  const t=ORDER.find(([s])=>s===slug)?.[3]||'OT';
  if(curTab!==t) switchTab(t);
  renderBook(slug);closeSB();
}
function openCh(slug,ch){
  curSlug=slug;curCh=ch;expBk=slug;
  const t=ORDER.find(([s])=>s===slug)?.[3]||'OT';
  if(curTab!==t) switchTab(t);
  renderCh(slug,ch);rebuildSB();closeSB();window.scrollTo(0,0);
}

// ── HOME ──
// Curated list of well-known verses for daily verse
const VOTD_POOL=[
  ['genesis','1','1'],['genesis','1','3'],['psalms','23','1'],['psalms','23','4'],
  ['psalms','46','1'],['psalms','119','105'],['psalms','91','1'],['psalms','121','1'],
  ['psalms','1','1'],['proverbs','3','5'],['proverbs','3','6'],['proverbs','16','3'],
  ['proverbs','22','6'],['isaiah','40','31'],['isaiah','41','10'],['jeremiah','29','11'],
  ['lamentations','3','23'],['john','3','16'],['john','14','6'],['john','14','27'],
  ['john','15','5'],['john','16','33'],['romans','8','28'],['romans','8','38'],
  ['romans','12','2'],['philippians','4','6'],['philippians','4','7'],
  ['philippians','4','13'],['philippians','4','19'],['galatians','5','22'],
  ['ephesians','2','8'],['ephesians','2','10'],['ephesians','6','10'],
  ['2-timothy','3','16'],['hebrews','11','1'],['hebrews','13','8'],
  ['1-corinthians','13','4'],['1-corinthians','13','13'],['1-corinthians','10','13'],
  ['james','1','5'],['1-peter','5','7'],['revelation','3','20'],
  ['matthew','5','3'],['matthew','6','33'],['matthew','11','28'],
  ['matthew','22','37'],['mark','10','27'],['luke','1','37']
];
function getDailyVerse(){
  // Random every time the page loads (not date-based)
  var pool=VOTD_POOL.filter(function(e){
    var s=e[0],c=+e[1],v=+e[2];
    return TM[s]&&TM[s].chapters&&TM[s].chapters[c]&&TM[s].chapters[c][v];
  });
  if(!pool.length) return null;
  var pick=pool[Math.floor(Math.random()*pool.length)];
  var slug=pick[0],ch=+pick[1],vn=+pick[2];
  var tm=TM[slug].chapters[ch][vn]||'';
  var en=(EN[slug]&&EN[slug][ch]?EN[slug][ch][vn]||'':'');
  return {slug:slug,ch:ch,vn:vn,tm:tm,en:en,ta:TA[slug]||'',enName:ENname[slug]||''};
}
function renderHome(){
  const mkCards=(bks)=>bks.map(([slug,,en,])=>{
    const ta=TA[slug];
    const ch=Object.keys(TM[slug]?.chapters||{}).length;
    return `<div class="bk-card" onclick="showBook('${slug}')">
      <span class="bk-ta">${ta}</span>
      <span class="bk-en">${en}</span>
      <span class="bk-ch">${ch} அத்தியாயங்கள்</span>
    </div>`;
  }).join('');
  const dv=getDailyVerse();
  const votdHtml=dv?`
    <div class="votd-box" style="cursor:pointer" onclick="openCh('${dv.slug}',${dv.ch})" title="கிளிக் செய்து வசனம் படிக்கவும்">
      <div class="votd-lbl">✦ இன்றைய வசனம்</div>
      <div class="votd-ta">${dv.tm}</div>
      ${dv.en?`<div class="votd-en" style="font-size:.78rem;color:#888;font-style:italic;font-family:Georgia,serif;margin-top:4px;line-height:1.6">${dv.en}</div>`:''}
      <div class="votd-ref">${dv.ta} ${dv.ch}:${dv.vn} – ${dv.enName} ${dv.ch}:${dv.vn}</div>
    </div>`:``;
  document.getElementById('main').innerHTML=`
    <div class="home-hero">
      <span class="home-cross">✞</span>
      <div class="home-title">பரிசுத்த வேதாகமம்</div>
      <div class="home-sub">Tamil Bible · 31,102 வசனங்கள்</div>
    </div>
    ${votdHtml}
    <div class="test-section">
      <div class="test-hdr ot"><h2>பழைய ஏற்பாடு</h2><span>Old Testament – 39 Books</span></div>
      <div class="books-grid">${mkCards(ORDER.filter(([,,,t])=>t==='OT'))}</div>
    </div>
    <div class="test-section">
      <div class="test-hdr nt"><h2>புதிய ஏற்பாடு</h2><span>New Testament – 27 Books</span></div>
      <div class="books-grid">${mkCards(ORDER.filter(([,,,t])=>t==='NT'))}</div>
    </div>`;
}

// ── BOOK ──
function renderBook(slug){
  const ta=TA[slug],en=ENname[slug];
  const chs=Object.keys(TM[slug]?.chapters||{}).map(Number).sort((a,b)=>a-b);
  const tiles=chs.map(c=>`<div class="ch-tile" onclick="openCh('${slug}',${c})">${c}</div>`).join('');
  document.getElementById('main').innerHTML=`
    <div class="bc"><a onclick="showHome()">முகப்பு</a><span class="sep">›</span><span>${ta} – ${en}</span></div>
    <div class="bk-pg-hdr">
      <h2>${ta} – ${en}</h2>
      <p>${chs.length} அத்தியாயங்கள்</p>
    </div>
    <div class="ch-grid-lbl">அத்தியாயம் தேர்ந்தெடுக்கவும்</div>
    <div class="ch-grid">${tiles}</div>`;
}

// ── CHAPTER ──
function renderCh(slug,ch){
  const ta=TA[slug],en=ENname[slug];
  const bkChs=Object.keys(TM[slug]?.chapters||{}).map(Number).sort((a,b)=>a-b);
  const verses=TM[slug]?.chapters?.[ch]||TM[slug]?.chapters?.[String(ch)]||{};
  const enCh=EN[slug]?.[ch]||EN[slug]?.[String(ch)]||{};
  const vNums=Object.keys(verses).map(Number).sort((a,b)=>a-b);

  const ribbon=bkChs.map(c=>`<span class="rb${c===ch?' cur':''}" onclick="openCh('${slug}',${c})">${c}</span>`).join('');
  const jOpts=bkChs.map(c=>`<option value="${c}"${c===ch?' selected':''}>${c}</option>`).join('');
  const hasPrev=ch>bkChs[0],hasNext=ch<bkChs[bkChs.length-1];

  let vHtml='';
  if(!vNums.length){
    vHtml=`<div class="empty"><span class="ei">📖</span>வசனங்கள் கிடைக்கவில்லை</div>`;
  } else {
    vNums.forEach(vn=>{
      const tmTxt=verses[vn]||'';
      const enTxt=enCh[vn]||enCh[String(vn)]||'';
      const enPart=showEN&&enTxt?`<span class="v-en">${enTxt}</span>`:'';
      vHtml+=`<div class="verse-card">
        ${extraV(slug,ch,vn)}
        <div class="v-acts">
          <button class="v-act" onclick="cpV('${slug}',${ch},${vn})">📋</button>
          <button class="v-act" onclick="openSov('${slug}',${ch},${vn})">🖼 அட்டை</button>
          <button class="v-act" onclick="shrV('${slug}',${ch},${vn})">🔗</button>
          <button class="v-act" onclick="showAddToList('${slug}',${ch},${vn})">📋+</button>
        </div>
        <div class="v-inner">
          <span class="v-num" style="color:var(--vc)">${vn}</span>
          <span class="v-body">
            <span class="v-ta" style="color:var(--vc);font-size:var(--vfs)">${tmTxt}</span>
            ${enPart}
          </span>
        </div>
      </div>`;
    });
  }

  // Toolbar
  const txC=[['#c62828','சிவ'],['#1565c0','நீல'],['#2e7d32','பச்'],['#4a148c','ஊதா'],['#e65100','ஆர'],['#000','கரு'],['#fff','வெள்']];
  const bgC=[['#fffdf8','வெண்'],['#fff8e1','தேன்'],['#e3f2fd','வான்'],['#e8f5e9','பச்'],['#1a1a2e','இரவு'],['#2d2d2d','கரு']];
  const txSw=txC.map(([c,n])=>`<div class="sw${c===vc?' on':''}" style="background:${c};border-color:${c==='#fff'?'#ccc':c}" onclick="setVC('${c}')" title="${n}"></div>`).join('');
  const bgSw=bgC.map(([c,n])=>`<div class="sw${c===vbg?' on':''}" style="background:${c};border-color:${c==='#fffdf8'?'#ccc':'#555'}" onclick="setVBG('${c}')" title="${n}"></div>`).join('');
  const fsSel=[14,16,18,20,22,24,26,28,30].map(s=>`<option value="${s}"${s===vfs?' selected':''}>${s}px</option>`).join('');

  document.getElementById('main').innerHTML=`
    <div class="bc">
      <a onclick="showHome()">முகப்பு</a><span class="sep">›</span>
      <a onclick="showBook('${slug}')">${ta}</a><span class="sep">›</span>
      <span>அத்தியாரம் ${ch}</span>
    </div>
    <div class="ch-hdr">
      <div class="ch-title">${ta} ${ch} – ${en} Chapter ${ch}</div>
      <div class="ch-nav-row">
        <button class="nav-btn" onclick="openCh('${slug}',${ch-1})" ${hasPrev?'':'disabled'}>← முந்தைய</button>
        <button class="nav-btn" onclick="openCh('${slug}',${ch+1})" ${hasNext?'':'disabled'}>அடுத்தது →</button>
        <span class="nav-sep"></span>
        <div class="ch-jump"><span>அத்:</span>
          <select onchange="openCh('${slug}',+this.value)">${jOpts}</select>
        </div>
      </div>
    </div>
    <div class="ribbon"><span class="ribbon-lbl">Chapters:</span>${ribbon}</div>
    <div class="toolbar">
      <div class="tb-grp">
        <span class="tb-lbl">எழுத்து:</span>
        <button class="tb-btn" onclick="chFS(-2)">A−</button>
        <button class="tb-btn" onclick="chFS(2)">A+</button>
        <select class="tb-sel" onchange="setFS(+this.value)">${fsSel}</select>
      </div>
      <div class="tb-div"></div>
      <div class="tb-grp"><span class="tb-lbl">நிறம்:</span>${txSw}</div>
      <div class="tb-div"></div>
      <div class="tb-grp"><span class="tb-lbl">பின்:</span>${bgSw}</div>
      <div class="tb-div"></div>
      <div class="tb-grp">
        <button class="tb-btn${showEN?' on':''}" onclick="toggleEN()">English</button>
        <button class="tb-btn" onclick="cpAll('${slug}',${ch})">📋 அனைத்தும்</button>
      </div>
    </div>
    <div id="vlist">${vHtml}</div>
    <div style="display:flex;justify-content:space-between;margin-top:10px;gap:8px">
      <button class="nav-btn" onclick="openCh('${slug}',${ch-1})" ${hasPrev?'':'disabled'}>← முந்தைய</button>
      <button class="nav-btn" onclick="openCh('${slug}',${ch+1})" ${hasNext?'':'disabled'}>அடுத்தது →</button>
    </div>`;
}

// ── CUSTOMISATION ──
function chFS(d){vfs=Math.min(32,Math.max(12,vfs+d));document.documentElement.style.setProperty('--vfs',vfs+'px');saveS();}
function setFS(s){vfs=s;document.documentElement.style.setProperty('--vfs',s+'px');saveS();if(curSlug&&curCh)renderCh(curSlug,curCh);}
function setVC(c){vc=c;document.documentElement.style.setProperty('--vc',c);saveS();if(curSlug&&curCh)renderCh(curSlug,curCh);}
function setVBG(c){
  vbg=c;vbd=(['#1a1a2e','#2d2d2d'].includes(c))?'#444':'#e8ddd0';
  document.documentElement.style.setProperty('--vbg',c);
  document.documentElement.style.setProperty('--vbd',vbd);
  saveS();if(curSlug&&curCh)renderCh(curSlug,curCh);
}
function toggleEN(){showEN=!showEN;saveS();if(curSlug&&curCh)renderCh(curSlug,curCh);}

// ── SEARCH ──
let srResults=[], srPage=1;
const SR_PER_PAGE=50;

function doSearch(){
  const q=(document.getElementById('hdr-q').value||document.getElementById('srch-inp')?.value||'').trim();
  if(!q) return;
  document.getElementById('hdr-q').value=q;
  renderSearch(q);
}
function renderSearch(q){
  curSlug=null;curCh=null;
  document.getElementById('main').innerHTML=`
    <div class="bc"><a onclick="showHome()">முகப்பு</a><span class="sep">›</span><span>தேடல்</span></div>
    <div class="srch-box">
      <h2>📖 வசன தேடல்</h2>
      <div class="srch-row">
        <input type="text" id="srch-inp" placeholder="தமிழ் அல்லது English..." value="${q.replace(/"/g,'&quot;')}" onkeydown="if(event.key==='Enter')doSearch()"/>
        <button onclick="doSearch()">தேடு</button>
      </div>
      <div class="srch-filters">
        <span class="sf-lbl">வடிகட்டு:</span>
        <button class="sf-btn${srFilter==='ALL'?' on':''}" onclick="setSF('ALL',this)">அனைத்தும்</button>
        <button class="sf-btn${srFilter==='OT'?' on':''}" onclick="setSF('OT',this)">பழைய ஏற்பாடு</button>
        <button class="sf-btn${srFilter==='NT'?' on':''}" onclick="setSF('NT',this)">புதிய ஏற்பாடு</button>
      </div>
    </div>
    <div id="sr-results"></div>`;
  if(q) runSearch(q);
}
function setSF(f,btn){
  srFilter=f;
  document.querySelectorAll('.sf-btn').forEach(b=>b.classList.remove('on'));
  btn.classList.add('on');
  const q=document.getElementById('srch-inp')?.value.trim();
  if(q) runSearch(q);
}
function runSearch(q){
  const el=document.getElementById('sr-results');
  if(!q||q.length<2){el.innerHTML='<div class="sr-empty">2+ எழுத்துகளை உள்ளிடவும்</div>';return;}
  el.innerHTML='<div style="text-align:center;padding:20px;color:#999">தேடுகிறது...</div>';
  setTimeout(()=>{
    const results=[];
    const ql=q.toLowerCase();
    ORDER.forEach(([slug,,,t])=>{
      if(srFilter!=='ALL'&&t!==srFilter) return;
      const bk=TM[slug];if(!bk?.chapters) return;
      Object.entries(bk.chapters).forEach(([ch,vss])=>{
        Object.entries(vss).forEach(([vn,txt])=>{
          const enTxt=EN[slug]?.[+ch]?.[+vn]||EN[slug]?.[ch]?.[vn]||'';
          // Match Tamil or English
          if(txt.includes(q)||enTxt.toLowerCase().includes(ql)){
            results.push({slug,ch:+ch,vn:+vn,txt,enTxt,ta:TA[slug],en:ENname[slug],t});
          }
        });
      });
    });
    srResults=results;
    srPage=1;
    renderSrPage(q);
  },50);
}
function renderSrPage(q){
  const el=document.getElementById('sr-results');
  if(!srResults.length){
    el.innerHTML=`<div class="sr-empty"><div style="font-size:40px;opacity:.3">😔</div>"${q}" க்கு வசனம் கிடைக்கவில்லை</div>`;
    return;
  }
  const total=srResults.length;
  const totalPages=Math.ceil(total/SR_PER_PAGE);
  const start=(srPage-1)*SR_PER_PAGE;
  const pageResults=srResults.slice(start,start+SR_PER_PAGE);
  const ql=q.toLowerCase();
  const hl=txt=>txt.replace(new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'gi'),m=>`<mark>${m}</mark>`);
  const hlEn=txt=>txt.replace(new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'gi'),m=>`<mark>${m}</mark>`);

  let html=`<div class="srch-stats"><strong>${total}</strong> வசனங்கள் கிடைத்தன — "${q}" · பக்கம் <strong>${srPage}</strong> / ${totalPages} (${start+1}–${Math.min(start+SR_PER_PAGE,total)})</div>`;

  pageResults.forEach(r=>{
    html+=`<div class="sr-card" onclick="openCh('${r.slug}',${r.ch})">
      <div class="sr-ref">${r.ta} ${r.ch}:${r.vn} · ${r.en} ${r.ch}:${r.vn}</div>
      <div class="sr-ta">${hl(r.txt)}</div>
      ${r.enTxt?`<div class="sr-en">${hlEn(r.enTxt)}</div>`:''}
    </div>`;
  });

  // Pagination bar
  if(totalPages>1){
    html+=`<div class="pg-bar">`;
    html+=`<button class="pg-btn" onclick="goSrPage(${srPage-1},'${q}')" ${srPage===1?'disabled':''}>‹ முந்தைய</button>`;
    // Page number buttons
    const pages=getPgRange(srPage,totalPages);
    let prev=null;
    pages.forEach(p=>{
      if(prev!==null&&p-prev>1) html+=`<span class="pg-ellipsis">…</span>`;
      html+=`<button class="pg-btn${p===srPage?' on':''}" onclick="goSrPage(${p},'${q}')">${p}</button>`;
      prev=p;
    });
    html+=`<button class="pg-btn" onclick="goSrPage(${srPage+1},'${q}')" ${srPage===totalPages?'disabled':''}>அடுத்தது ›</button>`;
    html+=`</div>`;
  }

  el.innerHTML=html;
}
function goSrPage(p,q){
  srPage=p;
  renderSrPage(q);
  document.getElementById('sr-results').scrollIntoView({behavior:'smooth',block:'start'});
}
function getPgRange(cur,total){
  // Show max 7 page buttons with smart ellipsis
  const pages=new Set();
  pages.add(1);pages.add(total);
  for(let i=Math.max(1,cur-2);i<=Math.min(total,cur+2);i++) pages.add(i);
  return [...pages].sort((a,b)=>a-b);
}

// ── SETTINGS PAGE ──
function showSettings(){
  const txC=[['#c62828','சிவப்பு'],['#1565c0','நீலம்'],['#2e7d32','பச்சை'],['#4a148c','ஊதா'],['#e65100','ஆரஞ்சு'],['#000000','கருப்பு'],['#ffffff','வெள்ளை']];
  const bgC=[['#fffdf8','வெண்மை'],['#fff8e1','தேன்'],['#e3f2fd','வான்நீலம்'],['#e8f5e9','இளம்பச்சை'],['#1a1a2e','இரவு'],['#2d2d2d','அடர்']];
  document.getElementById('main').innerHTML=`
    <div class="bc"><a onclick="showHome()">முகப்பு</a><span class="sep">›</span><span>அமைப்புகள்</span></div>
    <div style="background:var(--paper);border:1px solid #e0d6c8;border-radius:8px;padding:18px;max-width:480px">
      <h2 style="font-family:'Latha',serif;font-size:1rem;color:#1a237e;margin-bottom:16px">⚙ படிப்பு அமைப்புகள்</h2>
      <div style="margin-bottom:14px">
        <div style="font-size:.76rem;font-weight:bold;color:#555;margin-bottom:7px">எழுத்து அளவு</div>
        <div style="display:flex;gap:6px;flex-wrap:wrap">
          ${[14,16,18,20,22,24,26,28,30].map(s=>`<div onclick="setFS(${s})" style="padding:5px 11px;border:2px solid ${s===vfs?'var(--blue)':'#ddd'};border-radius:6px;cursor:pointer;font-size:${s}px;font-family:'Latha',serif">${s}</div>`).join('')}
        </div>
      </div>
      <div style="margin-bottom:14px">
        <div style="font-size:.76rem;font-weight:bold;color:#555;margin-bottom:7px">வசன நிறம்</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          ${txC.map(([c,n])=>`<div onclick="setVC('${c}')" style="text-align:center;cursor:pointer">
            <div style="width:28px;height:28px;background:${c};border-radius:50%;border:3px solid ${c===vc?'#333':'#ddd'};margin:0 auto 3px"></div>
            <span style="font-size:.58rem;color:#666;font-family:'Latha',serif">${n}</span>
          </div>`).join('')}
        </div>
      </div>
      <div style="margin-bottom:14px">
        <div style="font-size:.76rem;font-weight:bold;color:#555;margin-bottom:7px">பின்னணி நிறம்</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          ${bgC.map(([c,n])=>`<div onclick="setVBG('${c}')" style="text-align:center;cursor:pointer">
            <div style="width:28px;height:28px;background:${c};border-radius:50%;border:3px solid ${c===vbg?'#333':'#ccc'};margin:0 auto 3px"></div>
            <span style="font-size:.58rem;color:#666;font-family:'Latha',serif">${n}</span>
          </div>`).join('')}
        </div>
      </div>
      <div style="margin-bottom:14px">
        <div style="font-size:.76rem;font-weight:bold;color:#555;margin-bottom:7px">English வசனம்</div>
        <button class="tb-btn${showEN?' on':''}" onclick="toggleEN();this.classList.toggle('on',showEN)">
          ${showEN?'✓ காட்டு':'மறை'}
        </button>
      </div>
      <div style="font-size:.7rem;color:#aaa;text-align:center;margin-top:12px">அமைப்புகள் தானாக சேமிக்கப்படும்</div>
    </div>`;
}

// ── CLIPBOARD HELPER (works on file://, http, https) ──
function copyText(text){
  // Try modern API first
  if(navigator.clipboard&&navigator.clipboard.writeText){
    navigator.clipboard.writeText(text).then(()=>toast('✓ நகலெடுக்கப்பட்டது!')).catch(()=>fallbackCopy(text));
  } else {
    fallbackCopy(text);
  }
}
function fallbackCopy(text){
  const ta=document.createElement('textarea');
  ta.value=text;
  ta.style.cssText='position:fixed;top:-9999px;left:-9999px;opacity:0;font-size:16px';
  document.body.appendChild(ta);
  ta.focus();ta.select();
  try{
    document.execCommand('copy');
    toast('✓ நகலெடுக்கப்பட்டது!');
  }catch(e){
    toast('❌ நகலெடுக்க முடியவில்லை');
  }
  document.body.removeChild(ta);
}

// ── VERSE ACTIONS ──
function getV(slug,ch,vn){
  const tm=TM[slug]?.chapters?.[ch]?.[vn]||TM[slug]?.chapters?.[String(ch)]?.[String(vn)]||'';
  const en=EN[slug]?.[ch]?.[vn]||EN[slug]?.[String(ch)]?.[String(vn)]||'';
  return {tm,en};
}
function getRef(slug,ch,vn){
  return {ta:`${TA[slug]} ${ch}:${vn}`,en:`${ENname[slug]} ${ch}:${vn}`};
}
function cpV(slug,ch,vn){
  const {tm,en}=getV(slug,ch,vn);const r=getRef(slug,ch,vn);
  copyText(`${tm}\n${en}\n— ${r.ta}`);
}
function cpAll(slug,ch){
  const vs=TM[slug]?.chapters?.[ch]||{};
  const enCh=EN[slug]?.[ch]||{};
  const ta=TA[slug],en=ENname[slug];
  const lines=[`${ta} ${ch} – ${en} Chapter ${ch}`,'─'.repeat(40),''];
  Object.keys(vs).map(Number).sort((a,b)=>a-b).forEach(v=>{
    lines.push(`${v}. ${vs[v]}`);
    if(enCh[v]) lines.push(`   ${enCh[v]}`);
    lines.push('');
  });
  copyText(lines.join('\n'));
}

// ── SHARE CARD ──
let sovSlug=null,sovCh=null,sovVn=null;
function openSov(slug,ch,vn){
  const {tm,en}=getV(slug,ch,vn);const r=getRef(slug,ch,vn);
  sovSlug=slug;sovCh=ch;sovVn=vn;
  document.getElementById('sc-ta').textContent=tm;
  document.getElementById('sc-en').textContent=en;
  document.getElementById('sc-r1').textContent=r.ta;
  document.getElementById('sc-r2').textContent=r.en;
  document.getElementById('sov').classList.add('on');
}
function closeSov(){document.getElementById('sov').classList.remove('on');}

function cpCard(){
  const ta=document.getElementById('sc-ta').textContent;
  const en=document.getElementById('sc-en').textContent;
  const r=document.getElementById('sc-r1').textContent;
  copyText(`${ta}\n${en}\n— ${r}`);
}

async function shareAsImage(){
  const card=document.getElementById('sc-wrap');
  toast('படம் உருவாக்குகிறது...');
  try {
    const canvas=await html2canvas(card,{
      backgroundColor:'#1a237e',
      scale:3,
      useCORS:true,
      logging:false,
      width:card.offsetWidth,
      height:card.offsetHeight
    });
    canvas.toBlob(async(blob)=>{
      if(!blob){toast('❌ படம் உருவாக்க முடியவில்லை');return;}
      const file=new File([blob],'bible-verse.png',{type:'image/png'});
      if(navigator.canShare&&navigator.canShare({files:[file]})){
        try{
          await navigator.share({files:[file],title:document.getElementById('sc-r1').textContent});
          toast('✓ பகிரப்பட்டது!');
        }catch(e){
          if(e.name!=='AbortError') downloadImg(canvas);
        }
      } else {
        downloadImg(canvas);
      }
    },'image/png');
  } catch(e){
    toast('❌ Error: '+e.message);
  }
}

function downloadImg(canvas){
  const link=document.createElement('a');
  link.download='bible-verse.png';
  link.href=canvas.toDataURL('image/png');
  link.click();
  toast('✓ படம் சேமிக்கப்பட்டது!');
}

async function webShr(){
  const ta=document.getElementById('sc-ta').textContent;
  const en=document.getElementById('sc-en').textContent;
  const r=document.getElementById('sc-r1').textContent;
  const txt=`${ta}\n${en}\n— ${r}`;
  if(navigator.share){
    try{await navigator.share({title:r,text:txt});}catch(e){if(e.name!=='AbortError')copyText(txt);}
  } else {
    copyText(txt);
  }
}

async function shrV(slug,ch,vn){
  const {tm,en}=getV(slug,ch,vn);const r=getRef(slug,ch,vn);
  const txt=`${tm}\n${en}\n— ${r.ta}`;
  if(navigator.share){
    try{await navigator.share({title:r.ta,text:txt});}catch(e){if(e.name!=='AbortError')copyText(txt);}
  } else {
    copyText(txt);
  }
}

function toast(msg){
  const el=document.getElementById('toast');
  el.textContent=msg;el.classList.add('on');
  setTimeout(()=>el.classList.remove('on'),2400);
}

// ── INIT ──
buildSB('OT','');
renderHome();
