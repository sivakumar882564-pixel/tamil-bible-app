# பரிசுத்த வேதாகமம் — APK Build Guide

## Project Structure
```
TamilBibleAPK/
├── app/
│   ├── src/main/
│   │   ├── assets/
│   │   │   ├── index.html          ← Main HTML entry point
│   │   │   ├── css/
│   │   │   │   └── style.css       ← All UI styles (21KB)
│   │   │   └── js/
│   │   │       ├── data-tm.js      ← Tamil Bible text (4.5MB)
│   │   │       ├── data-en.js      ← English KJV text (4.1MB)
│   │   │       ├── data-order.js   ← Book order + names
│   │   │       └── app.js          ← All app logic (49KB)
│   │   ├── java/com/tamilbible/app/
│   │   │   └── MainActivity.java
│   │   ├── res/
│   │   │   ├── layout/activity_main.xml
│   │   │   ├── values/ (strings, colors, styles)
│   │   │   └── mipmap-*/ic_launcher.png
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## METHOD 1: Build on Phone using AIDE (Free, No PC)

### Step 1 — Install AIDE
- Download **AIDE** from Play Store (free)
- Also download **AIDE Web** plugin from Play Store

### Step 2 — Copy project to phone
- Extract this ZIP to your phone storage
- Path example: `/sdcard/TamilBibleAPK/`

### Step 3 — Open in AIDE
1. Open AIDE
2. Tap **Open project**
3. Navigate to `/sdcard/TamilBibleAPK/`
4. Select the folder → AIDE detects it as Android project

### Step 4 — Build APK
1. Tap **⚙ → Build → Build APK**
2. Wait 2–5 minutes (first build downloads dependencies)
3. APK saved to: `TamilBibleAPK/app/build/outputs/apk/debug/`
4. Tap **Install** when prompted

---

## METHOD 2: Build using Android Studio (PC — Recommended)

### Step 1 — Install Android Studio
- Download from developer.android.com/studio (free)
- Install with default settings (~3GB)

### Step 2 — Open project
1. Open Android Studio
2. **File → Open** → select `TamilBibleAPK/` folder
3. Wait for Gradle sync (~2 minutes)

### Step 3 — Build APK
- **Build → Build Bundle(s)/APK(s) → Build APK(s)**
- APK location: `app/build/outputs/apk/debug/TamilBible-v1.0-debug.apk`

### Step 4 — Install on phone
- Transfer APK to phone via USB or WhatsApp to yourself
- Enable "Install from unknown sources" in phone settings
- Tap APK to install

---

## METHOD 3: Buildozer online (No install needed)

1. Go to **appetize.io** or **github.com**
2. Create repository, upload this project
3. Add GitHub Actions workflow (free CI/CD):

Create `.github/workflows/build.yml`:
```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with:
          java-version: '17'
          distribution: 'temurin'
      - name: Build APK
        run: |
          cd TamilBibleAPK
          chmod +x gradlew
          ./gradlew assembleDebug
      - name: Upload APK
        uses: actions/upload-artifact@v3
        with:
          name: TamilBible-APK
          path: TamilBibleAPK/app/build/outputs/apk/debug/*.apk
```

Push to GitHub → Actions tab → Download APK artifact. **100% free.**

---

## APK Details
- **Package:** com.tamilbible.app
- **Min Android:** 5.0 (API 21)
- **Target Android:** 14 (API 34)
- **Estimated APK size:** ~9–10 MB
- **Works offline:** ✅ Yes (all data embedded in assets)
- **localStorage:** ✅ Yes (favorites, quiz, goals persist)

## Troubleshooting
- **White screen:** Check that all 4 JS files are in `assets/js/`
- **Fonts not loading:** App needs internet first time for Google Fonts
- **Build fails:** Ensure Java 8+ is installed; run `./gradlew --version`
